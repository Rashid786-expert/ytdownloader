import os
import re
import logging
import tempfile
import threading
from datetime import datetime
from urllib.parse import urlparse, parse_qs
from flask import Flask, render_template, request, jsonify, send_file, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
import yt_dlp
from werkzeug.middleware.proxy_fix import ProxyFix
from sqlalchemy.orm import DeclarativeBase

class Base(DeclarativeBase):
    pass

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "fallback_secret_key_for_dev")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Database configuration
database_url = os.environ.get("DATABASE_URL")
if database_url and database_url.startswith("postgres://"):
    database_url = database_url.replace("postgres://", "postgresql://", 1)

app.config["SQLALCHEMY_DATABASE_URI"] = database_url or "sqlite:///temp.db"
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize database
db = SQLAlchemy(model_class=Base)
db.init_app(app)
migrate = Migrate(app, db)

# Database Models
class DownloadHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    video_id = db.Column(db.String(50), nullable=False, index=True)
    video_title = db.Column(db.String(255), nullable=False)
    video_url = db.Column(db.String(500), nullable=False)
    download_type = db.Column(db.String(10), nullable=False)  # 'video' or 'audio'
    format_quality = db.Column(db.String(20), nullable=False)  # '1080p', '320kbps', etc.
    file_size = db.Column(db.String(20))  # File size in MB/GB
    ip_address = db.Column(db.String(45))  # Support both IPv4 and IPv6
    user_agent = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    download_duration = db.Column(db.Float)  # Download time in seconds
    status = db.Column(db.String(20), default='completed')  # 'completed', 'failed', 'in_progress'

    def __repr__(self):
        return f'<DownloadHistory {self.video_title[:30]}... - {self.download_type}>'

class VideoAnalytics(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    video_id = db.Column(db.String(50), nullable=False, index=True)
    video_title = db.Column(db.String(255), nullable=False)
    video_url = db.Column(db.String(500), nullable=False)
    uploader = db.Column(db.String(100))
    duration = db.Column(db.Integer)  # Duration in seconds
    view_count = db.Column(db.BigInteger)
    access_count = db.Column(db.Integer, default=1)  # How many times this video was accessed
    first_accessed = db.Column(db.DateTime, default=datetime.utcnow)
    last_accessed = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    
    def __repr__(self):
        return f'<VideoAnalytics {self.video_title[:30]}... - {self.access_count} accesses>'

class SiteStats(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False, unique=True, index=True)
    total_downloads = db.Column(db.Integer, default=0)
    mp4_downloads = db.Column(db.Integer, default=0)
    mp3_downloads = db.Column(db.Integer, default=0)
    unique_visitors = db.Column(db.Integer, default=0)
    page_views = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<SiteStats {self.date} - {self.total_downloads} downloads>'

# Global dictionary to store download progress
download_progress = {}

class ProgressHook:
    def __init__(self, session_id):
        self.session_id = session_id
    
    def __call__(self, d):
        if d['status'] == 'downloading':
            percentage = d.get('_percent_str', '0%').strip()
            speed = d.get('_speed_str', 'Unknown')
            download_progress[self.session_id] = {
                'status': 'downloading',
                'percentage': percentage,
                'speed': speed
            }
        elif d['status'] == 'finished':
            download_progress[self.session_id] = {
                'status': 'finished',
                'percentage': '100%',
                'speed': 'Complete'
            }

def is_valid_youtube_url(url):
    """Validate if the URL is a valid YouTube URL"""
    youtube_regex = re.compile(
        r'(https?://)?(www\.)?(youtube|youtu|youtube-nocookie)\.(com|be)/'
        r'(watch\?v=|embed/|v/|.+\?v=)?([^&=%\?]{11})'
    )
    return youtube_regex.match(url) is not None

def extract_video_id(url):
    """Extract video ID from YouTube URL"""
    # Handle various YouTube URL formats
    if 'youtu.be/' in url:
        return url.split('youtu.be/')[-1].split('?')[0]
    elif 'watch?v=' in url:
        return parse_qs(urlparse(url).query)['v'][0]
    elif 'embed/' in url:
        return url.split('embed/')[-1].split('?')[0]
    return None

def get_video_info(url):
    """Extract video information using yt-dlp"""
    try:
        ydl_opts = {
            'quiet': True,
            'no_warnings': True,
        }
        
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            
            # Get available formats
            formats = []
            audio_formats = []
            
            for f in info.get('formats', []):
                if f.get('vcodec') != 'none' and f.get('acodec') != 'none':
                    # Video with audio
                    height = f.get('height')
                    if height:
                        quality = f"{height}p"
                        ext = f.get('ext', 'mp4')
                        filesize = f.get('filesize')
                        size_str = f"{filesize // (1024*1024)}MB" if filesize else "Unknown size"
                        
                        formats.append({
                            'format_id': f['format_id'],
                            'quality': quality,
                            'ext': ext,
                            'size': size_str,
                            'type': 'video'
                        })
                
                elif f.get('acodec') != 'none' and f.get('vcodec') == 'none':
                    # Audio only
                    abr = f.get('abr')
                    if abr:
                        quality = f"{int(abr)}kbps"
                        ext = f.get('ext', 'mp3')
                        filesize = f.get('filesize')
                        size_str = f"{filesize // (1024*1024)}MB" if filesize else "Unknown size"
                        
                        audio_formats.append({
                            'format_id': f['format_id'],
                            'quality': quality,
                            'ext': ext,
                            'size': size_str,
                            'type': 'audio'
                        })
            
            # Remove duplicates and sort
            seen_video = set()
            unique_formats = []
            for f in formats:
                if f['quality'] not in seen_video:
                    seen_video.add(f['quality'])
                    unique_formats.append(f)
            
            seen_audio = set()
            unique_audio = []
            for f in audio_formats:
                if f['quality'] not in seen_audio:
                    seen_audio.add(f['quality'])
                    unique_audio.append(f)
            
            # Sort by quality
            quality_order = {'2160p': 4, '1440p': 3, '1080p': 2, '720p': 1, '480p': 0, '360p': -1, '240p': -2, '144p': -3}
            unique_formats.sort(key=lambda x: quality_order.get(x['quality'], -4), reverse=True)
            
            return {
                'title': info.get('title', 'Unknown Title'),
                'duration': info.get('duration', 0),
                'thumbnail': info.get('thumbnail', ''),
                'uploader': info.get('uploader', 'Unknown'),
                'view_count': info.get('view_count', 0),
                'video_formats': unique_formats[:6],  # Limit to top 6 qualities
                'audio_formats': unique_audio[:3],    # Limit to top 3 audio qualities
                'video_id': info.get('id', '')
            }
    except Exception as e:
        logging.error(f"Error extracting video info: {str(e)}")
        return None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/youtube-to-mp4')
def youtube_to_mp4():
    return render_template('youtube_to_mp4.html')

@app.route('/youtube-to-mp3')
def youtube_to_mp3():
    return render_template('youtube_to_mp3.html')

@app.route('/how-to-use')
def how_to_use():
    return render_template('how_to_use.html')

@app.route('/privacy-policy')
def privacy_policy():
    return render_template('privacy_policy.html')

@app.route('/terms-of-service')
def terms_of_service():
    return render_template('terms_of_service.html')

@app.route('/analyze', methods=['POST'])
def analyze_video():
    url = request.form.get('url', '').strip()
    
    if not url:
        flash('Please enter a YouTube URL', 'error')
        return redirect(url_for('index'))
    
    if not is_valid_youtube_url(url):
        flash('Please enter a valid YouTube URL', 'error')
        return redirect(url_for('index'))
    
    video_info = get_video_info(url)
    
    if not video_info:
        flash('Failed to retrieve video information. Please check the URL and try again.', 'error')
        return redirect(url_for('index'))
    
    # Log video access for analytics
    log_video_access(video_info)
    
    return render_template('download.html', video_info=video_info, url=url)

@app.route('/download')
def download_video():
    url = request.args.get('url')
    format_id = request.args.get('format_id')
    download_type = request.args.get('type', 'video')
    
    if not url or not format_id:
        flash('Invalid download parameters', 'error')
        return redirect(url_for('index'))
    
    start_time = datetime.utcnow()
    video_info = None
    
    try:
        # Create temporary directory
        temp_dir = tempfile.mkdtemp()
        
        # Get video info for logging
        try:
            video_info = get_video_info(url)
        except:
            pass  # Continue with download even if we can't get video info
        
        if download_type == 'audio':
            # Download as MP3
            ydl_opts = {
                'format': format_id,
                'outtmpl': os.path.join(temp_dir, '%(title)s.%(ext)s'),
                'postprocessors': [{
                    'key': 'FFmpegExtractAudio',
                    'preferredcodec': 'mp3',
                    'preferredquality': '192',
                }],
            }
        else:
            # Download as video
            ydl_opts = {
                'format': format_id,
                'outtmpl': os.path.join(temp_dir, '%(title)s.%(ext)s'),
            }
        
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])
        
        # Find the downloaded file
        files = os.listdir(temp_dir)
        if files:
            downloaded_file = os.path.join(temp_dir, files[0])
            
            # Get file size for logging
            file_size = os.path.getsize(downloaded_file)
            file_size_mb = f"{file_size / (1024*1024):.1f}MB"
            
            # Calculate download duration
            download_duration = (datetime.utcnow() - start_time).total_seconds()
            
            # Log successful download
            if video_info:
                log_download(
                    video_id=video_info.get('video_id', ''),
                    video_title=video_info.get('title', 'Unknown'),
                    video_url=url,
                    download_type=download_type,
                    format_quality=format_id,
                    file_size=file_size_mb,
                    download_duration=download_duration,
                    status='completed'
                )
            
            # Get original filename for download
            filename = files[0]
            
            return send_file(
                downloaded_file,
                as_attachment=True,
                download_name=filename,
                mimetype='application/octet-stream'
            )
        else:
            # Log failed download
            if video_info:
                log_download(
                    video_id=video_info.get('video_id', ''),
                    video_title=video_info.get('title', 'Unknown'),
                    video_url=url,
                    download_type=download_type,
                    format_quality=format_id,
                    status='failed'
                )
            flash('Download failed. Please try again.', 'error')
            return redirect(url_for('index'))
            
    except Exception as e:
        # Log failed download
        if video_info:
            log_download(
                video_id=video_info.get('video_id', ''),
                video_title=video_info.get('title', 'Unknown'),
                video_url=url,
                download_type=download_type,
                format_quality=format_id,
                status='failed'
            )
        logging.error(f"Download error: {str(e)}")
        flash(f'Download failed: {str(e)}', 'error')
        return redirect(url_for('index'))

@app.route('/health')
def health_check():
    return {'status': 'healthy', 'service': 'YouTube Downloader'}

@app.route('/admin/dashboard')
def admin_dashboard():
    """Admin dashboard to view database statistics"""
    try:
        # Get recent downloads
        recent_downloads = DownloadHistory.query.order_by(DownloadHistory.created_at.desc()).limit(10).all()
        
        # Get popular videos
        popular_videos = VideoAnalytics.query.order_by(VideoAnalytics.access_count.desc()).limit(10).all()
        
        # Get daily stats for last 7 days
        from datetime import timedelta
        end_date = datetime.utcnow().date()
        start_date = end_date - timedelta(days=7)
        daily_stats = SiteStats.query.filter(
            SiteStats.date.between(start_date, end_date)
        ).order_by(SiteStats.date.desc()).all()
        
        # Get total counts
        total_downloads = db.session.query(DownloadHistory).count()
        total_videos_accessed = db.session.query(VideoAnalytics).count()
        mp4_downloads = db.session.query(DownloadHistory).filter_by(download_type='video').count()
        mp3_downloads = db.session.query(DownloadHistory).filter_by(download_type='audio').count()
        
        stats = {
            'total_downloads': total_downloads,
            'total_videos_accessed': total_videos_accessed,
            'mp4_downloads': mp4_downloads,
            'mp3_downloads': mp3_downloads,
            'recent_downloads': recent_downloads,
            'popular_videos': popular_videos,
            'daily_stats': daily_stats
        }
        
        return render_template('admin_dashboard.html', stats=stats)
        
    except Exception as e:
        logging.error(f"Admin dashboard error: {str(e)}")
        return f"Dashboard error: {str(e)}", 500

@app.route('/api/stats')
def api_stats():
    """API endpoint for basic stats"""
    try:
        today = datetime.utcnow().date()
        today_stats = SiteStats.query.filter_by(date=today).first()
        
        total_downloads = db.session.query(DownloadHistory).count()
        
        return {
            'total_downloads': total_downloads,
            'today_downloads': today_stats.total_downloads if today_stats else 0,
            'today_mp4': today_stats.mp4_downloads if today_stats else 0,
            'today_mp3': today_stats.mp3_downloads if today_stats else 0,
        }
    except Exception as e:
        return {'error': str(e)}, 500

# Database helper functions
def log_download(video_id, video_title, video_url, download_type, format_quality, 
                file_size=None, download_duration=None, status='completed'):
    """Log a download to the database"""
    try:
        download_record = DownloadHistory(
            video_id=video_id,
            video_title=video_title[:255],  # Ensure it fits in the column
            video_url=video_url[:500],
            download_type=download_type,
            format_quality=format_quality,
            file_size=file_size,
            ip_address=request.environ.get('HTTP_X_FORWARDED_FOR', request.remote_addr),
            user_agent=request.headers.get('User-Agent', '')[:500] if request.headers.get('User-Agent') else None,
            download_duration=download_duration,
            status=status
        )
        db.session.add(download_record)
        db.session.commit()
        
        # Update daily stats
        update_daily_stats(download_type)
        
    except Exception as e:
        logging.error(f"Failed to log download: {str(e)}")
        db.session.rollback()

def log_video_access(video_info):
    """Log video access for analytics"""
    try:
        video_id = video_info.get('video_id', '')
        
        # Check if video already exists in analytics
        existing = VideoAnalytics.query.filter_by(video_id=video_id).first()
        
        if existing:
            existing.access_count += 1
            existing.last_accessed = datetime.utcnow()
        else:
            video_record = VideoAnalytics(
                video_id=video_id,
                video_title=video_info.get('title', '')[:255],
                video_url=request.form.get('url', '')[:500],
                uploader=video_info.get('uploader', '')[:100] if video_info.get('uploader') else None,
                duration=video_info.get('duration', 0),
                view_count=video_info.get('view_count', 0)
            )
            db.session.add(video_record)
        
        db.session.commit()
        
    except Exception as e:
        logging.error(f"Failed to log video access: {str(e)}")
        db.session.rollback()

def update_daily_stats(download_type=None):
    """Update daily statistics"""
    try:
        today = datetime.utcnow().date()
        
        # Get or create today's stats
        stats = SiteStats.query.filter_by(date=today).first()
        if not stats:
            stats = SiteStats(date=today)
            db.session.add(stats)
        
        # Update counters - ensure they're initialized
        if stats.mp4_downloads is None:
            stats.mp4_downloads = 0
        if stats.mp3_downloads is None:
            stats.mp3_downloads = 0
        if stats.total_downloads is None:
            stats.total_downloads = 0
            
        if download_type == 'video':
            stats.mp4_downloads += 1
        elif download_type == 'audio':
            stats.mp3_downloads += 1
            
        stats.total_downloads += 1
        stats.updated_at = datetime.utcnow()
        
        db.session.commit()
        
    except Exception as e:
        logging.error(f"Failed to update daily stats: {str(e)}")
        db.session.rollback()

# Create database tables
with app.app_context():
    try:
        db.create_all()
        logging.info("Database tables created successfully")
    except Exception as e:
        logging.error(f"Failed to create database tables: {str(e)}")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
