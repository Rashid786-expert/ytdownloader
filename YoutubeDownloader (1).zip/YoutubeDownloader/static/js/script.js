// YouTube Downloader JavaScript

document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    // Initialize URL input validation
    initURLValidation();
    
    // Initialize download buttons
    initDownloadButtons();
    
    // Initialize form submission
    initFormSubmission();
    
    // Auto-dismiss alerts
    autoDismissAlerts();
    
    // Initialize tooltips
    initTooltips();
}

function initURLValidation() {
    const urlInput = document.querySelector('input[name="url"]');
    if (!urlInput) return;
    
    urlInput.addEventListener('input', function() {
        validateYouTubeURL(this.value);
    });
    
    urlInput.addEventListener('paste', function(e) {
        setTimeout(() => {
            validateYouTubeURL(this.value);
        }, 100);
    });
}

function validateYouTubeURL(url) {
    const urlInput = document.querySelector('input[name="url"]');
    const submitBtn = document.querySelector('button[type="submit"]');
    
    if (!url) {
        resetValidation();
        return;
    }
    
    const youtubeRegex = /^(https?:\/\/)?(www\.)?(youtube|youtu|youtube-nocookie)\.(com|be)\/(watch\?v=|embed\/|v\/|.+\?v=)?([^&=%\?]{11})/;
    
    if (youtubeRegex.test(url)) {
        urlInput.classList.remove('is-invalid');
        urlInput.classList.add('is-valid');
        submitBtn.disabled = false;
        showFeedback('Valid YouTube URL!', 'success');
    } else {
        urlInput.classList.remove('is-valid');
        urlInput.classList.add('is-invalid');
        submitBtn.disabled = true;
        showFeedback('Please enter a valid YouTube URL', 'error');
    }
}

function resetValidation() {
    const urlInput = document.querySelector('input[name="url"]');
    const submitBtn = document.querySelector('button[type="submit"]');
    const feedback = document.querySelector('.url-feedback');
    
    if (urlInput) {
        urlInput.classList.remove('is-valid', 'is-invalid');
    }
    if (submitBtn) {
        submitBtn.disabled = false;
    }
    if (feedback) {
        feedback.remove();
    }
}

function showFeedback(message, type) {
    // Remove existing feedback
    const existingFeedback = document.querySelector('.url-feedback');
    if (existingFeedback) {
        existingFeedback.remove();
    }
    
    const urlInput = document.querySelector('input[name="url"]');
    const feedback = document.createElement('div');
    feedback.className = `url-feedback small mt-1 ${type === 'success' ? 'text-success' : 'text-danger'}`;
    feedback.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-triangle'} me-1"></i>${message}`;
    
    urlInput.parentNode.appendChild(feedback);
}

function initFormSubmission() {
    const form = document.querySelector('form');
    if (!form) return;
    
    form.addEventListener('submit', function(e) {
        const submitBtn = this.querySelector('button[type="submit"]');
        const urlInput = this.querySelector('input[name="url"]');
        
        if (!urlInput.value.trim()) {
            e.preventDefault();
            showAlert('Please enter a YouTube URL', 'error');
            return;
        }
        
        // Show loading state
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="loading me-2"></span>Analyzing...';
        }
        
        // Show processing message
        showProcessingMessage();
    });
}

function initDownloadButtons() {
    const downloadButtons = document.querySelectorAll('a[href*="/download"]');
    
    downloadButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            // Show loading state
            this.classList.add('loading');
            this.innerHTML = '<span class="loading me-2"></span>Preparing...';
            this.style.pointerEvents = 'none';
            
            // Show download preparation message
            showAlert('Preparing your download... This may take a few moments.', 'info');
            
            // Reset button after timeout (in case of issues)
            setTimeout(() => {
                resetDownloadButton(this);
            }, 30000);
        });
    });
}

function resetDownloadButton(button) {
    button.classList.remove('loading');
    button.style.pointerEvents = 'auto';
    
    // Restore original text based on button content
    if (button.href.includes('type=video')) {
        const quality = button.closest('.card-body').querySelector('.badge').textContent;
        button.innerHTML = '<i class="fas fa-download me-1"></i>Download';
    } else if (button.href.includes('type=audio')) {
        button.innerHTML = '<i class="fas fa-download me-1"></i>Download';
    }
}

function showProcessingMessage() {
    const container = document.querySelector('.hero-section .container');
    if (!container) return;
    
    const messageDiv = document.createElement('div');
    messageDiv.className = 'processing-message text-center mt-4';
    messageDiv.innerHTML = `
        <div class="alert alert-info">
            <div class="d-flex align-items-center justify-content-center">
                <span class="loading me-3"></span>
                <div>
                    <strong>Processing your request...</strong><br>
                    <small>Retrieving video information from YouTube</small>
                </div>
            </div>
        </div>
    `;
    
    container.appendChild(messageDiv);
}

function showAlert(message, type) {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show`;
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // Insert at the top of the main container
    const container = document.querySelector('.container');
    if (container) {
        container.insertBefore(alertDiv, container.firstChild);
    }
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.classList.remove('show');
            setTimeout(() => {
                if (alertDiv.parentNode) {
                    alertDiv.remove();
                }
            }, 150);
        }
    }, 5000);
}

function autoDismissAlerts() {
    const alerts = document.querySelectorAll('.alert:not(.alert-dismissible)');
    
    alerts.forEach(alert => {
        setTimeout(() => {
            if (alert.parentNode) {
                alert.classList.add('fade');
                setTimeout(() => {
                    if (alert.parentNode) {
                        alert.remove();
                    }
                }, 150);
            }
        }, 5000);
    });
}

function initTooltips() {
    // Initialize Bootstrap tooltips if available
    if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
}

// Utility functions
function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

function formatDuration(seconds) {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hrs > 0) {
        return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    } else {
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    }
}

// Handle page visibility changes to reset states
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        // Page is hidden, user might have started a download
        return;
    }
    
    // Page is visible again, reset any loading states
    const loadingButtons = document.querySelectorAll('.btn.loading');
    loadingButtons.forEach(resetDownloadButton);
});

// Handle browser back button
window.addEventListener('pageshow', function(event) {
    if (event.persisted) {
        // Page was restored from cache, reset form states
        const form = document.querySelector('form');
        if (form) {
            form.reset();
        }
        resetValidation();
    }
});

// Prevent multiple form submissions
let formSubmitted = false;
document.addEventListener('submit', function(e) {
    if (formSubmitted) {
        e.preventDefault();
        return false;
    }
    formSubmitted = true;
    
    // Reset after 3 seconds to allow retry if needed
    setTimeout(() => {
        formSubmitted = false;
    }, 3000);
});
