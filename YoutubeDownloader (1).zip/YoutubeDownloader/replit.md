# YouTube Downloader Application

## Overview

This is a Flask-based web application that allows users to download YouTube videos in various formats (MP3/MP4). The application provides a simple web interface for entering YouTube URLs, analyzing video information, and downloading content with real-time progress tracking.

## User Preferences

Preferred communication style: Simple, everyday language.
User wants website features similar to yt1z.net and yt1d.com including header menu with theme sections, dedicated pages for YouTube to MP4/MP3, and language selection functionality.

## System Architecture

### Frontend Architecture
- **Technology**: HTML5, CSS3, JavaScript, Bootstrap 5.3.0
- **UI Framework**: Bootstrap for responsive design and components
- **Icons**: Font Awesome 6.0.0 for consistent iconography
- **Architecture Pattern**: Traditional server-side rendered templates with progressive enhancement via JavaScript
- **Responsive Design**: Mobile-first approach using Bootstrap grid system

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **Architecture Pattern**: MVC (Model-View-Controller) with Flask's blueprint structure
- **Session Management**: Flask's built-in session handling with configurable secret key
- **Middleware**: ProxyFix for handling reverse proxy headers
- **Logging**: Python's built-in logging module configured for DEBUG level

## Key Components

### Core Application (`app.py`)
- **Main Flask Application**: Central application setup and configuration
- **Download Progress Tracking**: Global dictionary-based progress storage for real-time updates
- **URL Validation**: YouTube URL validation using regex patterns
- **Video Processing**: Integration with yt-dlp for video downloading and metadata extraction
- **Multi-page Routing**: Dedicated routes for YouTube to MP4, MP3, help pages, and legal pages

### Progress Hook System
- **Real-time Updates**: Custom progress hook class for tracking download status
- **Session-based Tracking**: Individual progress tracking per user session
- **Status Management**: Handles downloading, finished, and error states

### Frontend Components
- **Base Template** (`templates/base.html`): Common layout with navigation header, footer, and language switching
- **Landing Page** (`templates/index.html`): Main interface for URL input and validation
- **Download Page** (`templates/download.html`): Video information display and format selection
- **YouTube to MP4 Page** (`templates/youtube_to_mp4.html`): Dedicated video download interface
- **YouTube to MP3 Page** (`templates/youtube_to_mp3.html`): Dedicated audio extraction interface
- **How to Use Page** (`templates/how_to_use.html`): Complete user guide with FAQ section
- **Privacy Policy** (`templates/privacy_policy.html`): Data handling and privacy information
- **Terms of Service** (`templates/terms_of_service.html`): Service terms and user responsibilities
- **Custom Styling** (`static/css/style.css`): YouTube-themed design with navigation styling
- **Interactive JavaScript** (`static/js/script.js`): Client-side validation and language switching

## Data Flow

1. **URL Submission**: User enters YouTube URL on the main page
2. **Server Validation**: Flask backend validates URL format using regex
3. **Video Analysis**: yt-dlp extracts video metadata and available formats
4. **Format Selection**: User chooses desired download format (MP3/MP4)
5. **Download Processing**: Server initiates download with progress tracking
6. **Real-time Updates**: Progress hook provides status updates to the frontend
7. **File Delivery**: Completed download is served to user via Flask's send_file

## External Dependencies

### Python Libraries
- **Flask**: Web framework for routing and template rendering
- **yt-dlp**: YouTube video downloading and metadata extraction
- **Werkzeug**: WSGI utilities including ProxyFix middleware

### Frontend Dependencies (CDN)
- **Bootstrap 5.3.0**: CSS framework for responsive design
- **Font Awesome 6.0.0**: Icon library for UI elements

### Third-party Integrations
- **YouTube**: Primary content source via yt-dlp library
- **CDN Services**: External hosting for CSS and JavaScript libraries

## Deployment Strategy

### Environment Configuration
- **Secret Key**: Configurable via environment variable `SESSION_SECRET`
- **Debug Mode**: Controlled through Flask's built-in configuration
- **Proxy Support**: ProxyFix middleware for deployment behind reverse proxies

### File Structure
- **Entry Point**: `main.py` imports and runs the Flask application
- **Static Assets**: Organized in `static/` directory with subdirectories for CSS and JS
- **Templates**: Jinja2 templates in `templates/` directory
- **Temporary Files**: Uses Python's tempfile module for handling downloads

### Scalability Considerations
- **Session Storage**: Currently uses in-memory dictionary (suitable for single-instance deployment)
- **File Handling**: Temporary file management for download processing
- **Progress Tracking**: Session-based tracking allows multiple concurrent users

### Security Features
- **URL Validation**: Strict YouTube URL validation to prevent malicious inputs
- **Session Management**: Secure session handling with configurable secret keys
- **Input Sanitization**: Template engine handles output escaping automatically